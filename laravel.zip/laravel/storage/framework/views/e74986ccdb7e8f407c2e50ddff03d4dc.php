<h2>New Submission Received</h2>

<p><strong>Name:</strong> <?php echo e($data['name'] ?? 'N/A'); ?></p>
<p><strong>Date of Birth:</strong> <?php echo e($data['dob'] ?? 'N/A'); ?></p>
<p><strong>Mobile:</strong> <?php echo e($data['mobile'] ?? $data['org_mobile'] ?? 'N/A'); ?></p>
<p><strong>Email:</strong> <?php echo e($data['email'] ?? $data['org_email'] ?? 'N/A'); ?></p>

<p><strong>Country:</strong> <?php echo e($data['country'] ?? 'N/A'); ?></p>
<p><strong>State:</strong> <?php echo e($data['state'] ?? 'N/A'); ?></p>
<p><strong>City:</strong> <?php echo e($data['city'] ?? 'N/A'); ?></p>
<p><strong>Zip:</strong> <?php echo e($data['zip'] ?? 'N/A'); ?></p>

<p><strong>Description:</strong> <?php echo e($data['description'] ?? 'N/A'); ?></p>

<h3>Organization Information (if applicable)</h3>
<p><strong>Apply For:</strong> <?php echo e($data['applyFor'] ?? 'N/A'); ?></p>
<p><strong>Company Name:</strong> <?php echo e($data['company_name'] ?? 'N/A'); ?></p>
<p><strong>Designation:</strong> <?php echo e($data['designation'] ?? 'N/A'); ?></p>
<p><strong>Company Type:</strong> <?php echo e($data['company_type'] ?? 'N/A'); ?></p>
<?php /**PATH C:\xampp\htdocs\LUCA World Records\laravel\resources\views/emails/form.blade.php ENDPATH**/ ?>